#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Генератор data.sql: чтение xlsx из ресурсов, очистка и формирование INSERT."""
import os
import datetime
import openpyxl

BASE = "/home/user01/Рабочий стол/миша/экзамен"
IMPORT = os.path.join(
    BASE,
    "Прил_В3_КОД 09.02.07-2-2026-БУ/Модуль 1/"
    "Прил_2_ОЗ_КОД 09.02.07-2-2026-М1/import",
)
IMAGES = os.path.join(BASE, "Решение/app/images")
OUT = os.path.join(BASE, "Решение/db/data.sql")


def q(value):
    """Экранирование строкового значения для SQL."""
    if value is None:
        return "NULL"
    text = str(value).strip()
    if text == "":
        return "NULL"
    return "'" + text.replace("'", "''") + "'"


def clean(value):
    """Очистка строки от краевых пробелов."""
    if value is None:
        return None
    text = str(value).strip()
    return text if text else None


def load(name):
    work_book = openpyxl.load_workbook(os.path.join(IMPORT, name))
    sheet = work_book.active
    rows = [r for r in sheet.iter_rows(values_only=True)
            if any(c is not None for c in r)]
    return rows


def resolve_photo(photo):
    """Сопоставить имя фото с реально существующим файлом ресурсов."""
    if not photo:
        return None
    photo = str(photo).strip()
    if os.path.exists(os.path.join(IMAGES, photo)):
        return photo
    stem = os.path.splitext(photo)[0]
    for ext in (".jpg", ".jpeg", ".png"):
        if os.path.exists(os.path.join(IMAGES, stem + ext)):
            return stem + ext
    return None


def fmt_date(value):
    """Очистка даты: корректные приводим к ISO, некорректные -> NULL."""
    if isinstance(value, datetime.datetime):
        return "'" + value.date().isoformat() + "'"
    if isinstance(value, datetime.date):
        return "'" + value.isoformat() + "'"
    # Текстовая дата вида '30.02.2025' нереальна -> отбраковываем
    text = clean(value)
    if not text:
        return "NULL"
    for sep in (".", "-", "/"):
        parts = text.split(sep)
        if len(parts) == 3:
            try:
                day, month, year = (int(parts[0]), int(parts[1]),
                                    int(parts[2]))
                return "'" + datetime.date(year, month, day).isoformat() + "'"
            except ValueError:
                return "NULL"
    return "NULL"


lines = []


def w(text=""):
    lines.append(text)


# ----- Чтение исходных данных -----
tovar = load("Tovar.xlsx")[1:]
users = load("user_import.xlsx")[1:]
orders = load("Заказ_import.xlsx")[1:]
points = load("Пункты выдачи_import.xlsx")

# ----- Сбор справочников из данных товаров -----
units, categories, manufacturers, suppliers, roles, statuses = (
    [], [], [], [], [], [])


def reg(store, value):
    """Зарегистрировать значение в справочнике, вернуть его 1-based id."""
    value = clean(value)
    if value is None:
        return None
    if value not in store:
        store.append(value)
    return store.index(value) + 1


# Роли — фиксированный порядок
for role in ("Администратор", "Менеджер", "Авторизированный клиент"):
    reg(roles, role)

# Справочники из товаров
products = []
for row in tovar:
    article, name, unit, price, supplier, manuf, category, \
        discount, qty, descr, photo = row
    article = clean(article)
    if not article:
        continue
    products.append({
        "article": article,
        "name": clean(name),
        "unit": reg(units, unit),
        "price": float(price) if price is not None else 0,
        "supplier": reg(suppliers, supplier),
        "manuf": reg(manufacturers, manuf),
        "category": reg(categories, category),
        "discount": int(discount) if discount is not None else 0,
        "qty": int(qty) if qty is not None else 0,
        "descr": clean(descr),
        "photo": resolve_photo(photo),
    })

# Статусы и пункты выдачи
for row in orders:
    reg(statuses, row[7])
point_list = [clean(r[0]) for r in points if clean(r[0])]

# ----- Формирование SQL -----
w("-- ===================================================================")
w("-- Наполнение БД ООО «СтройМатериалы» (Модуль № 1).")
w("-- Данные подготовлены из файлов import: очистка пробелов,")
w("-- нормализация справочников, отбраковка некорректных дат.")
w("-- ===================================================================")
w("BEGIN;")
w("TRUNCATE order_items, orders, products, users, pickup_points,")
w("  order_statuses, suppliers, manufacturers, categories, units, roles")
w("  RESTART IDENTITY CASCADE;")
w("")

w("-- Роли")
for i, value in enumerate(roles, 1):
    w(f"INSERT INTO roles (role_id, role_name) VALUES ({i}, {q(value)});")
w("")

w("-- Единицы измерения")
for i, value in enumerate(units, 1):
    w(f"INSERT INTO units (unit_id, unit_name) VALUES ({i}, {q(value)});")
w("")

w("-- Категории")
for i, value in enumerate(categories, 1):
    w(f"INSERT INTO categories (category_id, category_name) "
      f"VALUES ({i}, {q(value)});")
w("")

w("-- Производители")
for i, value in enumerate(manufacturers, 1):
    w(f"INSERT INTO manufacturers (manufacturer_id, manufacturer_name) "
      f"VALUES ({i}, {q(value)});")
w("")

w("-- Поставщики")
for i, value in enumerate(suppliers, 1):
    w(f"INSERT INTO suppliers (supplier_id, supplier_name) "
      f"VALUES ({i}, {q(value)});")
w("")

w("-- Статусы заказов")
for i, value in enumerate(statuses, 1):
    w(f"INSERT INTO order_statuses (status_id, status_name) "
      f"VALUES ({i}, {q(value)});")
w("")

w("-- Пункты выдачи")
for i, value in enumerate(point_list, 1):
    w(f"INSERT INTO pickup_points (pickup_id, address) "
      f"VALUES ({i}, {q(value)});")
w("")

# ----- Пользователи (с привязкой по ФИО к id) -----
user_id_by_name = {}
w("-- Пользователи")
for i, row in enumerate(users, 1):
    role, full_name, login, password = row[0], row[1], row[2], row[3]
    role_id = reg(roles, role)
    full_name = clean(full_name)
    user_id_by_name.setdefault(full_name, i)
    w(f"INSERT INTO users (user_id, full_name, login, password, role_id) "
      f"VALUES ({i}, {q(full_name)}, {q(login)}, {q(password)}, {role_id});")
w("")

# ----- Товары -----
article_to_id = {}
w("-- Товары")
for i, p in enumerate(products, 1):
    article_to_id[p["article"]] = i
    w("INSERT INTO products (product_id, article, name, description, "
      "unit_id, category_id, manufacturer_id, supplier_id, price, "
      "discount, quantity, photo) VALUES (")
    w(f"  {i}, {q(p['article'])}, {q(p['name'])}, {q(p['descr'])}, "
      f"{p['unit']}, {p['category']}, {p['manuf']}, {p['supplier']}, "
      f"{p['price']:.2f}, {p['discount']}, {p['qty']}, {q(p['photo'])});")
w("")


def resolve_article(raw):
    """Сопоставить артикул из заказа с существующим товаром (исправ. опечаток)."""
    art = clean(raw)
    if not art:
        return None
    if art in article_to_id:
        return article_to_id[art]
    # Опечатки вида 'O43COU8' -> 'O43COU': отсекаем лишние хвостовые символы
    while len(art) > 5:
        art = art[:-1]
        if art in article_to_id:
            return article_to_id[art]
    return None


# ----- Заказы и позиции заказа -----
w("-- Заказы")
items_sql = []
for row in orders:
    order_no = int(row[0])
    articles_raw = clean(row[1]) or ""
    order_date = fmt_date(row[2])
    delivery_date = fmt_date(row[3])
    pickup_no = int(row[4]) if row[4] is not None else None
    client_name = clean(row[5])
    receive_code = int(row[6]) if row[6] is not None else 0
    status_id = reg(statuses, row[7])
    client_id = user_id_by_name.get(client_name)

    if order_date == "NULL":          # дата заказа обязательна — пропуск брака
        continue
    if client_id is None or pickup_no is None:
        continue

    w(f"INSERT INTO orders (order_id, order_date, delivery_date, "
      f"pickup_id, client_id, receive_code, status_id) VALUES "
      f"({order_no}, {order_date}, {delivery_date}, {pickup_no}, "
      f"{client_id}, {receive_code}, {status_id});")

    # Разбор строки "артикул, кол-во, артикул, кол-во, ..."
    tokens = [t.strip() for t in articles_raw.split(",") if t.strip()]
    seen = set()
    for k in range(0, len(tokens) - 1, 2):
        pid = resolve_article(tokens[k])
        try:
            cnt = int(tokens[k + 1])
        except ValueError:
            cnt = 1
        if pid and cnt > 0 and pid not in seen:
            seen.add(pid)
            items_sql.append(
                f"INSERT INTO order_items (order_id, product_id, quantity) "
                f"VALUES ({order_no}, {pid}, {cnt});")
w("")

w("-- Позиции заказов")
for line in items_sql:
    w(line)
w("")
w("-- Синхронизация последовательностей SERIAL после вставки с явными id")
for table, col in [
        ("roles", "role_id"), ("units", "unit_id"),
        ("categories", "category_id"),
        ("manufacturers", "manufacturer_id"), ("suppliers", "supplier_id"),
        ("order_statuses", "status_id"), ("pickup_points", "pickup_id"),
        ("users", "user_id"), ("products", "product_id"),
        ("order_items", "order_item_id")]:
    w(f"SELECT setval(pg_get_serial_sequence('{table}', '{col}'), "
      f"(SELECT COALESCE(MAX({col}), 1) FROM {table}));")
w("")
w("COMMIT;")

with open(OUT, "w", encoding="utf-8") as out_file:
    out_file.write("\n".join(lines) + "\n")

print("data.sql сформирован:", OUT)
print("товаров:", len(products), "| пользователей:", len(users),
      "| заказов(сырых):", len(orders), "| пунктов:", len(point_list))
