-- ===================================================================
-- Наполнение БД ООО «СтройМатериалы» (Модуль № 1).
-- Данные подготовлены из файлов import: очистка пробелов,
-- нормализация справочников, отбраковка некорректных дат.
-- ===================================================================
BEGIN;
TRUNCATE order_items, orders, products, users, pickup_points,
  order_statuses, suppliers, manufacturers, categories, units, roles
  RESTART IDENTITY CASCADE;

-- Роли
INSERT INTO roles (role_id, role_name) VALUES (1, 'Администратор');
INSERT INTO roles (role_id, role_name) VALUES (2, 'Менеджер');
INSERT INTO roles (role_id, role_name) VALUES (3, 'Авторизированный клиент');

-- Единицы измерения
INSERT INTO units (unit_id, unit_name) VALUES (1, 'шт.');

-- Категории
INSERT INTO categories (category_id, category_name) VALUES (1, 'Общестроительные материалы');
INSERT INTO categories (category_id, category_name) VALUES (2, 'Стеновые и фасадные материалы');
INSERT INTO categories (category_id, category_name) VALUES (3, 'Сухие строительные смеси и гидроизоляция');
INSERT INTO categories (category_id, category_name) VALUES (4, 'Ручной инструмент');
INSERT INTO categories (category_id, category_name) VALUES (5, 'Защита лица, глаз, головы');

-- Производители
INSERT INTO manufacturers (manufacturer_id, manufacturer_name) VALUES (1, 'М500');
INSERT INTO manufacturers (manufacturer_id, manufacturer_name) VALUES (2, 'Изостронг');
INSERT INTO manufacturers (manufacturer_id, manufacturer_name) VALUES (3, 'Knauf');
INSERT INTO manufacturers (manufacturer_id, manufacturer_name) VALUES (4, 'MixMaster');
INSERT INTO manufacturers (manufacturer_id, manufacturer_name) VALUES (5, 'ЛСР');
INSERT INTO manufacturers (manufacturer_id, manufacturer_name) VALUES (6, 'ВОЛМА');
INSERT INTO manufacturers (manufacturer_id, manufacturer_name) VALUES (7, 'Vinylon');
INSERT INTO manufacturers (manufacturer_id, manufacturer_name) VALUES (8, 'Павловский завод');
INSERT INTO manufacturers (manufacturer_id, manufacturer_name) VALUES (9, 'Weber');
INSERT INTO manufacturers (manufacturer_id, manufacturer_name) VALUES (10, 'Hesler');
INSERT INTO manufacturers (manufacturer_id, manufacturer_name) VALUES (11, 'Armero');
INSERT INTO manufacturers (manufacturer_id, manufacturer_name) VALUES (12, 'Wenzo Roma');
INSERT INTO manufacturers (manufacturer_id, manufacturer_name) VALUES (13, 'KILIMGRIN');
INSERT INTO manufacturers (manufacturer_id, manufacturer_name) VALUES (14, 'Исток');
INSERT INTO manufacturers (manufacturer_id, manufacturer_name) VALUES (15, 'RUIZ');
INSERT INTO manufacturers (manufacturer_id, manufacturer_name) VALUES (16, 'Husqvarna');
INSERT INTO manufacturers (manufacturer_id, manufacturer_name) VALUES (17, 'Delta');

-- Поставщики
INSERT INTO suppliers (supplier_id, supplier_name) VALUES (1, 'М500');
INSERT INTO suppliers (supplier_id, supplier_name) VALUES (2, 'Изостронг');
INSERT INTO suppliers (supplier_id, supplier_name) VALUES (3, 'Knauf');
INSERT INTO suppliers (supplier_id, supplier_name) VALUES (4, 'MixMaster');
INSERT INTO suppliers (supplier_id, supplier_name) VALUES (5, 'ЛСР');
INSERT INTO suppliers (supplier_id, supplier_name) VALUES (6, 'ВОЛМА');
INSERT INTO suppliers (supplier_id, supplier_name) VALUES (7, 'Vinylon');
INSERT INTO suppliers (supplier_id, supplier_name) VALUES (8, 'Павловский завод');
INSERT INTO suppliers (supplier_id, supplier_name) VALUES (9, 'Weber');
INSERT INTO suppliers (supplier_id, supplier_name) VALUES (10, 'Hesler');
INSERT INTO suppliers (supplier_id, supplier_name) VALUES (11, 'Armero');
INSERT INTO suppliers (supplier_id, supplier_name) VALUES (12, 'Wenzo Roma');
INSERT INTO suppliers (supplier_id, supplier_name) VALUES (13, 'KILIMGRIN');
INSERT INTO suppliers (supplier_id, supplier_name) VALUES (14, 'Исток');
INSERT INTO suppliers (supplier_id, supplier_name) VALUES (15, 'RUIZ');
INSERT INTO suppliers (supplier_id, supplier_name) VALUES (16, 'Husqvarna');
INSERT INTO suppliers (supplier_id, supplier_name) VALUES (17, 'Delta');

-- Статусы заказов
INSERT INTO order_statuses (status_id, status_name) VALUES (1, 'Завершен');
INSERT INTO order_statuses (status_id, status_name) VALUES (2, 'Новый');

-- Пункты выдачи
INSERT INTO pickup_points (pickup_id, address) VALUES (1, '420151, г. Лесной, ул. Вишневая, 32');
INSERT INTO pickup_points (pickup_id, address) VALUES (2, '125061, г. Лесной, ул. Подгорная, 8');
INSERT INTO pickup_points (pickup_id, address) VALUES (3, '630370, г. Лесной, ул. Шоссейная, 24');
INSERT INTO pickup_points (pickup_id, address) VALUES (4, '400562, г. Лесной, ул. Зеленая, 32');
INSERT INTO pickup_points (pickup_id, address) VALUES (5, '614510, г. Лесной, ул. Маяковского, 47');
INSERT INTO pickup_points (pickup_id, address) VALUES (6, '410542, г. Лесной, ул. Светлая, 46');
INSERT INTO pickup_points (pickup_id, address) VALUES (7, '620839, г. Лесной, ул. Цветочная, 8');
INSERT INTO pickup_points (pickup_id, address) VALUES (8, '443890, г. Лесной, ул. Коммунистическая, 1');
INSERT INTO pickup_points (pickup_id, address) VALUES (9, '603379, г. Лесной, ул. Спортивная, 46');
INSERT INTO pickup_points (pickup_id, address) VALUES (10, '603721, г. Лесной, ул. Гоголя, 41');
INSERT INTO pickup_points (pickup_id, address) VALUES (11, '410172, г. Лесной, ул. Северная, 13');
INSERT INTO pickup_points (pickup_id, address) VALUES (12, '614611, г. Лесной, ул. Молодежная, 50');
INSERT INTO pickup_points (pickup_id, address) VALUES (13, '454311, г.Лесной, ул. Новая, 19');
INSERT INTO pickup_points (pickup_id, address) VALUES (14, '660007, г.Лесной, ул. Октябрьская, 19');
INSERT INTO pickup_points (pickup_id, address) VALUES (15, '603036, г. Лесной, ул. Садовая, 4');
INSERT INTO pickup_points (pickup_id, address) VALUES (16, '394060, г.Лесной, ул. Фрунзе, 43');
INSERT INTO pickup_points (pickup_id, address) VALUES (17, '410661, г. Лесной, ул. Школьная, 50');
INSERT INTO pickup_points (pickup_id, address) VALUES (18, '625590, г. Лесной, ул. Коммунистическая, 20');
INSERT INTO pickup_points (pickup_id, address) VALUES (19, '625683, г. Лесной, ул. 8 Марта');
INSERT INTO pickup_points (pickup_id, address) VALUES (20, '450983, г.Лесной, ул. Комсомольская, 26');
INSERT INTO pickup_points (pickup_id, address) VALUES (21, '394782, г. Лесной, ул. Чехова, 3');
INSERT INTO pickup_points (pickup_id, address) VALUES (22, '603002, г. Лесной, ул. Дзержинского, 28');
INSERT INTO pickup_points (pickup_id, address) VALUES (23, '450558, г. Лесной, ул. Набережная, 30');
INSERT INTO pickup_points (pickup_id, address) VALUES (24, '344288, г. Лесной, ул. Чехова, 1');
INSERT INTO pickup_points (pickup_id, address) VALUES (25, '614164, г.Лесной,  ул. Степная, 30');
INSERT INTO pickup_points (pickup_id, address) VALUES (26, '394242, г. Лесной, ул. Коммунистическая, 43');
INSERT INTO pickup_points (pickup_id, address) VALUES (27, '660540, г. Лесной, ул. Солнечная, 25');
INSERT INTO pickup_points (pickup_id, address) VALUES (28, '125837, г. Лесной, ул. Шоссейная, 40');
INSERT INTO pickup_points (pickup_id, address) VALUES (29, '125703, г. Лесной, ул. Партизанская, 49');
INSERT INTO pickup_points (pickup_id, address) VALUES (30, '625283, г. Лесной, ул. Победы, 46');
INSERT INTO pickup_points (pickup_id, address) VALUES (31, '614753, г. Лесной, ул. Полевая, 35');
INSERT INTO pickup_points (pickup_id, address) VALUES (32, '426030, г. Лесной, ул. Маяковского, 44');
INSERT INTO pickup_points (pickup_id, address) VALUES (33, '450375, г. Лесной ул. Клубная, 44');
INSERT INTO pickup_points (pickup_id, address) VALUES (34, '625560, г. Лесной, ул. Некрасова, 12');
INSERT INTO pickup_points (pickup_id, address) VALUES (35, '630201, г. Лесной, ул. Комсомольская, 17');
INSERT INTO pickup_points (pickup_id, address) VALUES (36, '190949, г. Лесной, ул. Мичурина, 26');

-- Пользователи
INSERT INTO users (user_id, full_name, login, password, role_id) VALUES (1, 'Ворсин Петр Евгеньевич', '94d5ous@gmail.com', 'uzWC67', 1);
INSERT INTO users (user_id, full_name, login, password, role_id) VALUES (2, 'Старикова Елена Павловна', 'uth4iz@mail.com', '2L6KZG', 1);
INSERT INTO users (user_id, full_name, login, password, role_id) VALUES (3, 'Одинцов Серафим Артёмович', 'yzls62@outlook.com', 'JlFRCZ', 1);
INSERT INTO users (user_id, full_name, login, password, role_id) VALUES (4, 'Степанов Михаил Артёмович', '1diph5e@tutanota.com', '8ntwUp', 2);
INSERT INTO users (user_id, full_name, login, password, role_id) VALUES (5, 'Ворсин Петр Евгеньевич', 'tjde7c@yahoo.com', 'YOyhfR', 2);
INSERT INTO users (user_id, full_name, login, password, role_id) VALUES (6, 'Старикова Елена Павловна', 'wpmrc3do@tutanota.com', 'RSbvHv', 2);
INSERT INTO users (user_id, full_name, login, password, role_id) VALUES (7, 'Михайлюк Анна Вячеславовна', '5d4zbu@tutanota.com', 'rwVDh9', 3);
INSERT INTO users (user_id, full_name, login, password, role_id) VALUES (8, 'Ситдикова Елена Анатольевна', 'ptec8ym@yahoo.com', 'LdNyos', 3);
INSERT INTO users (user_id, full_name, login, password, role_id) VALUES (9, 'Никифорова Весения Николаевна', '1qz4kw@mail.com', 'gynQMT', 3);
INSERT INTO users (user_id, full_name, login, password, role_id) VALUES (10, 'Сазонов Руслан Германович', '4np6se@mail.com', 'AtnDjr', 3);

-- Товары
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  1, 'PMEZMH', 'Цемент', 'Цемент Евроцемент М500 Д0 ЦЕМ I 42,5 50 кг', 1, 1, 1, 1, 440.00, 8, 34, 'PMEZMH.jpg');
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  2, 'BPV4MM', 'Пленка техническая', 'Пленка техническая полиэтиленовая Изостронг 60 мк 3 м рукав 1,5 м, пог.м', 1, 1, 2, 2, 8.00, 8, 2, 'BPV4MM.jpg');
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  3, 'JVL42J', 'Пленка техническая', 'Пленка техническая полиэтиленовая Изостронг 100 мк 3 м рукав 1,5 м, пог.м', 1, 1, 2, 2, 13.00, 4, 34, 'JVL42J.jpg');
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  4, 'F895RB', 'Песок строительный', 'Песок строительный 50 кг', 1, 1, 3, 3, 102.00, 6, 7, 'F895RB.jpg');
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  5, '3XBOTN', 'Керамзит фракция', 'Керамзит фракция 10-20 мм 0,05 куб.м', 1, 1, 4, 4, 110.00, 5, 21, '3XBOTN.jpeg');
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  6, '3L7RCZ', 'Газобетон', 'Газобетон ЛСР 100х250х625 мм D400', 1, 2, 5, 5, 7400.00, 2, 20, '3L7RCZ.jpg');
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  7, 'S72AM3', 'Пазогребневая плита', 'Пазогребневая плита ВОЛМА Гидро 667х500х80 мм полнотелая', 1, 2, 6, 6, 500.00, 5, 35, 'S72AM3.jpg');
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  8, '2G3280', 'Угол наружный', 'Угол наружный Vinylon 3050 мм серо-голубой', 1, 2, 7, 7, 795.00, 9, 20, '2G3280.jpg');
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  9, 'MIO8YV', 'Кирпич', 'Кирпич рядовой Боровичи полнотелый М150 250х120х65 мм 1NF', 1, 2, 6, 6, 30.00, 9, 31, 'MIO8YV.jpg');
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  10, 'UER2QD', 'Скоба для пазогребневой плиты', 'Скоба для пазогребневой плиты Knauf С1 120х100 мм', 1, 2, 3, 3, 25.00, 8, 27, 'UER2QD.jpg');
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  11, 'ZR70B4', 'Кирпич', 'Кирпич рядовой силикатный Павловский завод полнотелый М200 250х120х65 мм 1NF', 1, 2, 8, 8, 16.00, 3, 0, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  12, 'LPDDM4', 'Штукатурка гипсовая', 'Штукатурка гипсовая Knauf Ротбанд 30 кг', 1, 3, 3, 3, 500.00, 6, 38, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  13, 'LQ48MW', 'Штукатурка гипсовая', 'Штукатурка гипсовая Knauf МП-75 машинная 30 кг', 1, 3, 9, 9, 462.00, 6, 33, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  14, 'O43COU', 'Шпаклевка', 'Шпаклевка полимерная Weber.vetonit LR + для сухих помещений белая 20 кг', 1, 3, 6, 6, 750.00, 1, 16, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  15, 'M26EXW', 'Клей для плитки, керамогранита и камня', 'Клей для плитки, керамогранита и камня Крепс Усиленный серый (класс С1) 25 кг', 1, 3, 3, 3, 340.00, 8, 0, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  16, 'K0YACK', 'Смесь цементно-песчаная', 'Смесь цементно-песчаная (ЦПС) 300 по ТУ MixMaster Универсал 25 кг', 1, 3, 4, 4, 160.00, 8, 19, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  17, 'ASPXSG', 'Ровнитель', 'Ровнитель (наливной пол) финишный Weber.vetonit 4100 самовыравнивающийся высокопрочный 20 кг', 1, 3, 9, 9, 711.00, 10, 20, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  18, 'ZKQ5FF', 'Лезвие для ножа', 'Лезвие для ножа Hesler 18 мм прямое (10 шт.)', 1, 4, 10, 10, 65.00, 6, 6, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  19, '4WZEOT', 'Лезвие для ножа', 'Лезвие для ножа Armero 18 мм прямое (10 шт.)', 1, 4, 11, 11, 110.00, 6, 17, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  20, '4JR1HN', 'Шпатель', 'Шпатель малярный 100 мм с пластиковой ручкой', 1, 4, 10, 10, 26.00, 6, 7, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  21, 'Z3XFSP', 'Нож строительный', 'Нож строительный Hesler 18 мм с ломающимся лезвием пластиковый корпус', 1, 4, 10, 10, 63.00, 8, 5, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  22, 'I6MH89', 'Валик', 'Валик Wenzo Roma полиакрил 250 мм ворс 18 мм для красок грунтов и антисептиков на водной основе с рукояткой', 1, 4, 12, 12, 326.00, 12, 3, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  23, '83M5ME', 'Кисть', 'Кисть плоская смешанная щетина 100х12 мм для красок и антисептиков на водной основе', 1, 4, 11, 11, 122.00, 9, 26, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  24, '61PGH3', 'Очки защитные', 'Очки защитные Delta Plus KILIMANDJARO (KILIMGRIN) открытые с прозрачными линзами', 1, 5, 13, 13, 184.00, 6, 25, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  25, 'GN6ICZ', 'Каска защитная', 'Каска защитная Исток (КАС001О) оранжевая', 1, 5, 14, 14, 154.00, 15, 8, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  26, 'Z3LO0U', 'Очки защитные', 'Очки защитные Delta Plus RUIZ (RUIZ1VI) закрытые с прозрачными линзами', 1, 5, 15, 15, 228.00, 9, 11, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  27, 'QHNOKR', 'Маска защитная', 'Маска защитная Исток (ЩИТ001) ударопрочная и термостойкая', 1, 5, 14, 14, 251.00, 2, 22, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  28, 'EQ6RKO', 'Подшлемник', 'Подшлемник для каски одноразовый', 1, 5, 16, 16, 36.00, 17, 22, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  29, '81F1WG', 'Каска защитная', 'Каска защитная Delta Plus BASEBALL DIAMOND V UP (DIAM5UPBCFLBS) белая', 1, 5, 17, 17, 1500.00, 2, 13, NULL);
INSERT INTO products (product_id, article, name, description, unit_id, category_id, manufacturer_id, supplier_id, price, discount, quantity, photo) VALUES (
  30, '0YGHZ7', 'Очки защитные', 'Очки защитные Husqvarna Clear (5449638-01) открытые с прозрачными линзами', 1, 5, 16, 16, 700.00, 9, 36, NULL);

-- Заказы
INSERT INTO orders (order_id, order_date, delivery_date, pickup_id, client_id, receive_code, status_id) VALUES (1, '2025-02-27', '2025-04-20', 1, 7, 901, 1);
INSERT INTO orders (order_id, order_date, delivery_date, pickup_id, client_id, receive_code, status_id) VALUES (2, '2024-09-28', '2025-04-21', 11, 8, 902, 1);
INSERT INTO orders (order_id, order_date, delivery_date, pickup_id, client_id, receive_code, status_id) VALUES (3, '2025-03-21', '2025-04-22', 2, 9, 903, 1);
INSERT INTO orders (order_id, order_date, delivery_date, pickup_id, client_id, receive_code, status_id) VALUES (4, '2025-02-20', '2025-04-23', 11, 10, 904, 1);
INSERT INTO orders (order_id, order_date, delivery_date, pickup_id, client_id, receive_code, status_id) VALUES (5, '2025-03-17', '2025-04-24', 2, 7, 905, 1);
INSERT INTO orders (order_id, order_date, delivery_date, pickup_id, client_id, receive_code, status_id) VALUES (6, '2025-03-01', '2025-04-25', 15, 8, 906, 1);
INSERT INTO orders (order_id, order_date, delivery_date, pickup_id, client_id, receive_code, status_id) VALUES (8, '2025-03-31', '2025-04-27', 19, 10, 908, 2);
INSERT INTO orders (order_id, order_date, delivery_date, pickup_id, client_id, receive_code, status_id) VALUES (9, '2025-04-02', '2025-04-28', 5, 9, 909, 2);
INSERT INTO orders (order_id, order_date, delivery_date, pickup_id, client_id, receive_code, status_id) VALUES (10, '2025-04-03', '2025-04-29', 19, 10, 910, 2);

-- Позиции заказов
INSERT INTO order_items (order_id, product_id, quantity) VALUES (1, 1, 2);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (1, 2, 2);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (2, 3, 1);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (2, 4, 1);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (3, 5, 10);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (3, 6, 10);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (4, 7, 5);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (4, 8, 4);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (5, 9, 2);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (5, 10, 2);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (6, 11, 1);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (6, 12, 1);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (8, 15, 5);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (8, 16, 4);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (9, 17, 5);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (9, 18, 1);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (10, 19, 5);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (10, 20, 5);

-- Синхронизация последовательностей SERIAL после вставки с явными id
SELECT setval(pg_get_serial_sequence('roles', 'role_id'), (SELECT COALESCE(MAX(role_id), 1) FROM roles));
SELECT setval(pg_get_serial_sequence('units', 'unit_id'), (SELECT COALESCE(MAX(unit_id), 1) FROM units));
SELECT setval(pg_get_serial_sequence('categories', 'category_id'), (SELECT COALESCE(MAX(category_id), 1) FROM categories));
SELECT setval(pg_get_serial_sequence('manufacturers', 'manufacturer_id'), (SELECT COALESCE(MAX(manufacturer_id), 1) FROM manufacturers));
SELECT setval(pg_get_serial_sequence('suppliers', 'supplier_id'), (SELECT COALESCE(MAX(supplier_id), 1) FROM suppliers));
SELECT setval(pg_get_serial_sequence('order_statuses', 'status_id'), (SELECT COALESCE(MAX(status_id), 1) FROM order_statuses));
SELECT setval(pg_get_serial_sequence('pickup_points', 'pickup_id'), (SELECT COALESCE(MAX(pickup_id), 1) FROM pickup_points));
SELECT setval(pg_get_serial_sequence('users', 'user_id'), (SELECT COALESCE(MAX(user_id), 1) FROM users));
SELECT setval(pg_get_serial_sequence('products', 'product_id'), (SELECT COALESCE(MAX(product_id), 1) FROM products));
SELECT setval(pg_get_serial_sequence('order_items', 'order_item_id'), (SELECT COALESCE(MAX(order_item_id), 1) FROM order_items));

COMMIT;
