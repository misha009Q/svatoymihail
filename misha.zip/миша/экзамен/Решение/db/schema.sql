-- =====================================================================
-- ООО «СтройМатериалы» — схема базы данных
-- СУБД: PostgreSQL. Нормализация: 3НФ, ссылочная целостность (PK/FK).
-- Модуль № 1 ДЭ 09.02.07-2-2026 (Вариант № 3)
-- =====================================================================

-- Чистое пересоздание схемы
DROP TABLE IF EXISTS order_items   CASCADE;
DROP TABLE IF EXISTS orders        CASCADE;
DROP TABLE IF EXISTS products      CASCADE;
DROP TABLE IF EXISTS users         CASCADE;
DROP TABLE IF EXISTS pickup_points CASCADE;
DROP TABLE IF EXISTS order_statuses CASCADE;
DROP TABLE IF EXISTS suppliers     CASCADE;
DROP TABLE IF EXISTS manufacturers CASCADE;
DROP TABLE IF EXISTS categories    CASCADE;
DROP TABLE IF EXISTS units         CASCADE;
DROP TABLE IF EXISTS roles         CASCADE;

-- ------------------------- Справочники -------------------------------

-- Роли пользователей (гость не хранится — это режим без записи)
CREATE TABLE roles (
    role_id   SERIAL      PRIMARY KEY,
    role_name VARCHAR(50) NOT NULL UNIQUE
);

-- Единицы измерения
CREATE TABLE units (
    unit_id   SERIAL      PRIMARY KEY,
    unit_name VARCHAR(20) NOT NULL UNIQUE
);

-- Категории товаров
CREATE TABLE categories (
    category_id   SERIAL       PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL UNIQUE
);

-- Производители
CREATE TABLE manufacturers (
    manufacturer_id   SERIAL       PRIMARY KEY,
    manufacturer_name VARCHAR(100) NOT NULL UNIQUE
);

-- Поставщики
CREATE TABLE suppliers (
    supplier_id   SERIAL       PRIMARY KEY,
    supplier_name VARCHAR(100) NOT NULL UNIQUE
);

-- Статусы заказов
CREATE TABLE order_statuses (
    status_id   SERIAL      PRIMARY KEY,
    status_name VARCHAR(50) NOT NULL UNIQUE
);

-- Пункты выдачи заказов
CREATE TABLE pickup_points (
    pickup_id SERIAL        PRIMARY KEY,
    address   VARCHAR(255)  NOT NULL UNIQUE
);

-- --------------------------- Пользователи ----------------------------

CREATE TABLE users (
    user_id    SERIAL        PRIMARY KEY,
    full_name  VARCHAR(150)  NOT NULL,
    login      VARCHAR(100)  NOT NULL UNIQUE,
    password   VARCHAR(100)  NOT NULL,
    role_id    INTEGER       NOT NULL
        REFERENCES roles (role_id) ON UPDATE CASCADE ON DELETE RESTRICT
);

-- --------------------------- Товары ----------------------------------

CREATE TABLE products (
    product_id      SERIAL        PRIMARY KEY,
    article         VARCHAR(20)   NOT NULL UNIQUE,
    name            VARCHAR(150)  NOT NULL,
    description     TEXT,
    unit_id         INTEGER       NOT NULL
        REFERENCES units (unit_id)            ON UPDATE CASCADE ON DELETE RESTRICT,
    category_id     INTEGER       NOT NULL
        REFERENCES categories (category_id)   ON UPDATE CASCADE ON DELETE RESTRICT,
    manufacturer_id INTEGER       NOT NULL
        REFERENCES manufacturers (manufacturer_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    supplier_id     INTEGER       NOT NULL
        REFERENCES suppliers (supplier_id)    ON UPDATE CASCADE ON DELETE RESTRICT,
    price           NUMERIC(10,2) NOT NULL CHECK (price >= 0),
    discount        INTEGER       NOT NULL DEFAULT 0
        CHECK (discount >= 0 AND discount <= 100),
    quantity        INTEGER       NOT NULL DEFAULT 0 CHECK (quantity >= 0),
    photo           VARCHAR(255)
);

-- --------------------------- Заказы ----------------------------------

CREATE TABLE orders (
    order_id      INTEGER     PRIMARY KEY,
    order_date    DATE        NOT NULL,
    delivery_date DATE,
    pickup_id     INTEGER     NOT NULL
        REFERENCES pickup_points (pickup_id)  ON UPDATE CASCADE ON DELETE RESTRICT,
    client_id     INTEGER     NOT NULL
        REFERENCES users (user_id)            ON UPDATE CASCADE ON DELETE RESTRICT,
    receive_code  INTEGER     NOT NULL,
    status_id     INTEGER     NOT NULL
        REFERENCES order_statuses (status_id) ON UPDATE CASCADE ON DELETE RESTRICT
);

-- Позиции заказа (разрешение связи M:N между orders и products).
CREATE TABLE order_items (
    order_item_id SERIAL  PRIMARY KEY,
    order_id      INTEGER NOT NULL
        REFERENCES orders (order_id)     ON UPDATE CASCADE ON DELETE CASCADE,
    product_id    INTEGER NOT NULL
        REFERENCES products (product_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    quantity      INTEGER NOT NULL CHECK (quantity > 0),
    UNIQUE (order_id, product_id)
);

-- Индексы для ускорения поиска / фильтрации / сортировки
CREATE INDEX idx_products_category     ON products (category_id);
CREATE INDEX idx_products_manufacturer ON products (manufacturer_id);
CREATE INDEX idx_orders_client         ON orders (client_id);
CREATE INDEX idx_order_items_product   ON order_items (product_id);
