#!/usr/bin/env bash
# Создание роли и базы данных, применение схемы и загрузка данных.
# Требует прав суперпользователя postgres (sudo).
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"

echo ">>> Создание роли и базы данных..."
sudo -u postgres psql -v ON_ERROR_STOP=1 <<'SQL'
DROP DATABASE IF EXISTS stroy_db;
DROP ROLE IF EXISTS stroy_app;
CREATE ROLE stroy_app WITH LOGIN PASSWORD 'stroy123';
CREATE DATABASE stroy_db WITH OWNER = stroy_app ENCODING 'UTF8';
SQL

export PGPASSWORD='stroy123'
echo ">>> Применение схемы (schema.sql)..."
psql -h 127.0.0.1 -U stroy_app -d stroy_db -v ON_ERROR_STOP=1 \
    -f "$DIR/db/schema.sql"

echo ">>> Загрузка данных (data.sql)..."
psql -h 127.0.0.1 -U stroy_app -d stroy_db -v ON_ERROR_STOP=1 \
    -f "$DIR/db/data.sql"

echo ">>> Готово. База данных stroy_db создана и наполнена."
