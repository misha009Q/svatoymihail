#!/usr/bin/env bash
# Запуск приложения ООО «СтройМатериалы».
# Пересоздание БД и наполнение выполняются скриптом setup_db.sh.
set -e
cd "$(dirname "$0")/app"
python3 main.py
