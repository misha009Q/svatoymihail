# -*- coding: utf-8 -*-
"""Единые стили приложения ООО «СтройМатериалы».

Все цвета и шрифты соответствуют руководству по стилю (Приложение 3):
  * основной фон    — белый  (#FFFFFF);
  * дополнительный фон — #DAA520;
  * акцент целевого действия — #B8860B;
  * фон строки при скидке > 12% — #F4A460;
  * шрифт — Calibri.
"""

# ----- Цвета из руководства по стилю -----
COLOR_BG = "#FFFFFF"          # основной фон
COLOR_SECONDARY = "#DAA520"   # дополнительный фон
COLOR_ACCENT = "#B8860B"      # акцентирование целевого действия
COLOR_DISCOUNT = "#F4A460"    # фон строки при скидке более 12%

# ----- Дополнительные служебные цвета (по заданию модуля 2) -----
COLOR_NO_STOCK = "#ADD8E6"    # голубой — товара нет на складе
COLOR_OLD_PRICE = "#FF0000"   # красный — перечёркнутая старая цена
COLOR_NEW_PRICE = "#000000"   # чёрный — итоговая цена
COLOR_TEXT = "#000000"
COLOR_WHITE = "#FFFFFF"

# Порог скидки, при превышении которого подсвечивается строка
DISCOUNT_THRESHOLD = 12

# ----- Шрифты (Calibri; Carlito — метрически совместимая замена) -----
FONT_FAMILY = "Calibri"
FONT_NORMAL = (FONT_FAMILY, 11)
FONT_BOLD = (FONT_FAMILY, 11, "bold")
FONT_TITLE = (FONT_FAMILY, 18, "bold")
FONT_SUBTITLE = (FONT_FAMILY, 14, "bold")
FONT_SMALL = (FONT_FAMILY, 9)
FONT_PRICE = (FONT_FAMILY, 12, "bold")
FONT_OLD_PRICE = (FONT_FAMILY, 10, "overstrike")
