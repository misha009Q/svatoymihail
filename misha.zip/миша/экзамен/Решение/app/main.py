# -*- coding: utf-8 -*-
"""Главный модуль приложения ООО «СтройМатериалы».

Точка входа. Управляет окном верхнего уровня и переключением экранов:
окно входа (авторизация) и окно списка товаров.
"""
import os
import sys
import tkinter as tk
from tkinter import messagebox

import styles
from db import Database
from login_screen import LoginScreen
from products_screen import ProductsScreen

# Каталог с ресурсами (иконка, логотип, заглушка)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESOURCES_DIR = os.path.join(BASE_DIR, "resources")
ICON_PATH = os.path.join(RESOURCES_DIR, "icon.png")


class Application(tk.Tk):
    """Корневое окно приложения и контроллер навигации."""

    def __init__(self):
        super().__init__()
        self.title("ООО «СтройМатериалы» — Вход")
        self.geometry("1100x720")
        self.minsize(900, 600)
        self.configure(bg=styles.COLOR_BG)

        # Установка иконки приложения из ресурсов
        try:
            self.icon_image = tk.PhotoImage(file=ICON_PATH)
            self.iconphoto(True, self.icon_image)
        except tk.TclError:
            pass  # если платформа не поддерживает — пропускаем

        # Подключение к базе данных с обработкой ошибки соединения
        try:
            self.db = Database()
        except Exception as error:  # noqa: BLE001
            messagebox.showerror(
                "Ошибка подключения",
                "Не удалось подключиться к базе данных.\n\n"
                f"Подробности: {error}")
            self.destroy()
            sys.exit(1)

        self.current_user = None   # данные авторизованного пользователя
        self.current_frame = None  # активный экран
        self.show_login()

    def _switch(self, frame_class, **kwargs):
        """Заменить текущий экран новым."""
        if self.current_frame is not None:
            self.current_frame.destroy()
        self.current_frame = frame_class(self, **kwargs)
        self.current_frame.pack(fill="both", expand=True)

    def show_login(self):
        """Показать окно входа (главный экран)."""
        self.current_user = None
        self.title("ООО «СтройМатериалы» — Вход")
        self._switch(LoginScreen)

    def login_as_guest(self):
        """Войти в режиме гостя (без записи в БД)."""
        self.current_user = {
            "user_id": None,
            "full_name": "Гость",
            "role_name": "Гость",
        }
        self.show_products()

    def login_as_user(self, user):
        """Сохранить авторизованного пользователя и открыть список товаров."""
        self.current_user = dict(user)
        self.show_products()

    def show_products(self):
        """Показать экран со списком товаров согласно роли."""
        role = self.current_user["role_name"]
        self.title(f"ООО «СтройМатериалы» — Товары ({role})")
        self._switch(ProductsScreen)

    def logout(self):
        """Выход на главный экран — окно входа."""
        self.show_login()


def main():
    """Запуск приложения."""
    app = Application()
    app.mainloop()


if __name__ == "__main__":
    main()
