# -*- coding: utf-8 -*-
"""Экран списка товаров с поиском, фильтрацией, сортировкой и подсветкой."""
import os
import tkinter as tk
from tkinter import messagebox

from PIL import Image, ImageTk

import styles
from product_form import ProductForm
from orders_screen import OrdersWindow

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
IMAGES_DIR = os.path.join(BASE_DIR, "images")
PLACEHOLDER = os.path.join(BASE_DIR, "resources", "picture.png")
LOGO_PATH = os.path.join(BASE_DIR, "resources", "icon.png")

# Размер миниатюры фото товара в списке
THUMB_SIZE = (90, 90)

# Параметры сортировки: подпись -> (поле БД, по убыванию)
SORT_OPTIONS = [
    ("Без сортировки", (None, False)),
    ("Цена (по возрастанию)", ("price", False)),
    ("Цена (по убыванию)", ("price", True)),
    ("Количество (по возрастанию)", ("quantity", False)),
    ("Количество (по убыванию)", ("quantity", True)),
    ("Скидка (по возрастанию)", ("discount", False)),
    ("Скидка (по убыванию)", ("discount", True)),
]


class ProductsScreen(tk.Frame):
    """Список товаров. Возможности зависят от роли пользователя."""

    def __init__(self, app):
        super().__init__(app, bg=styles.COLOR_BG)
        self.app = app
        self.db = app.db
        self.user = app.current_user
        self.role = self.user["role_name"]

        # Права доступа согласно роли
        self.can_manage_tools = self.role in ("Менеджер", "Администратор")
        self.can_edit = self.role == "Администратор"
        self.can_view_orders = self.role in ("Менеджер", "Администратор")

        self._thumb_cache = {}   # кэш миниатюр, чтобы их не собрал GC
        self._logo_image = None
        self._edit_window = None  # ссылка на открытое окно редактирования

        self._build_header()
        self._build_toolbar()
        self._build_list_area()
        self.reload_products()

    # --------------------------- Шапка -------------------------------
    def _build_header(self):
        """Верхняя панель: логотип, заголовок, ФИО, выход."""
        header = tk.Frame(self, bg=styles.COLOR_SECONDARY, height=64)
        header.pack(fill="x", side="top")
        header.pack_propagate(False)

        # Логотип компании на главной форме (из ресурсов, без искажений)
        try:
            image = Image.open(LOGO_PATH)
            image.thumbnail((48, 48), Image.LANCZOS)
            self._logo_image = ImageTk.PhotoImage(image)
            tk.Label(header, image=self._logo_image,
                     bg=styles.COLOR_SECONDARY).pack(side="left", padx=12)
        except Exception:  # noqa: BLE001
            pass

        tk.Label(header, text="Каталог товаров", font=styles.FONT_SUBTITLE,
                 bg=styles.COLOR_SECONDARY,
                 fg=styles.COLOR_WHITE).pack(side="left", pady=12)

        # Правый верхний угол: ФИО пользователя и кнопка выхода
        right = tk.Frame(header, bg=styles.COLOR_SECONDARY)
        right.pack(side="right", padx=12)

        tk.Button(right, text="Выход", command=self.app.logout,
                  font=styles.FONT_NORMAL, bg=styles.COLOR_ACCENT,
                  fg=styles.COLOR_WHITE, relief="flat", cursor="hand2",
                  activebackground=styles.COLOR_BG,
                  activeforeground=styles.COLOR_ACCENT).pack(side="right")

        tk.Label(right, text=f"{self.user['full_name']}  ({self.role})",
                 font=styles.FONT_BOLD, bg=styles.COLOR_SECONDARY,
                 fg=styles.COLOR_WHITE).pack(side="right", padx=12)

    # ------------------------ Панель инструментов --------------------
    def _build_toolbar(self):
        """Поиск, сортировка, фильтр (менеджер/админ) и кнопки действий."""
        toolbar = tk.Frame(self, bg=styles.COLOR_BG)
        toolbar.pack(fill="x", padx=12, pady=10)

        # Переменные управления (общие для всех ролей объявлены всегда)
        self.search_var = tk.StringVar()
        self.sort_var = tk.StringVar(value=SORT_OPTIONS[0][0])
        self.filter_var = tk.StringVar(value="Все производители")

        if self.can_manage_tools:
            # Поиск в реальном времени
            tk.Label(toolbar, text="Поиск:", font=styles.FONT_NORMAL,
                     bg=styles.COLOR_BG).pack(side="left")
            search_entry = tk.Entry(toolbar, textvariable=self.search_var,
                                    font=styles.FONT_NORMAL, width=24,
                                    relief="solid", bd=1)
            search_entry.pack(side="left", padx=(4, 14), ipady=3)
            self.search_var.trace_add("write",
                                      lambda *a: self.reload_products())

            # Сортировка
            tk.Label(toolbar, text="Сортировка:", font=styles.FONT_NORMAL,
                     bg=styles.COLOR_BG).pack(side="left")
            sort_menu = tk.OptionMenu(toolbar, self.sort_var,
                                      *[o[0] for o in SORT_OPTIONS],
                                      command=lambda *a: self.reload_products())
            sort_menu.config(font=styles.FONT_SMALL, relief="solid", bd=1,
                             bg=styles.COLOR_WHITE, highlightthickness=0)
            sort_menu.pack(side="left", padx=(4, 14))

            # Фильтр по производителю
            tk.Label(toolbar, text="Производитель:", font=styles.FONT_NORMAL,
                     bg=styles.COLOR_BG).pack(side="left")
            manufacturers = ["Все производители"] + [
                m["manufacturer_name"] for m in self.db.get_manufacturers()]
            self._manufacturer_map = {
                m["manufacturer_name"]: m["manufacturer_id"]
                for m in self.db.get_manufacturers()}
            filter_menu = tk.OptionMenu(
                toolbar, self.filter_var, *manufacturers,
                command=lambda *a: self.reload_products())
            filter_menu.config(font=styles.FONT_SMALL, relief="solid", bd=1,
                               bg=styles.COLOR_WHITE, highlightthickness=0)
            filter_menu.pack(side="left", padx=(4, 14))

        # Кнопка просмотра заказов (менеджер/админ)
        if self.can_view_orders:
            tk.Button(toolbar, text="Заказы", command=self._open_orders,
                      font=styles.FONT_NORMAL, bg=styles.COLOR_SECONDARY,
                      fg=styles.COLOR_WHITE, relief="flat", cursor="hand2",
                      activebackground=styles.COLOR_ACCENT,
                      activeforeground=styles.COLOR_WHITE).pack(
                          side="right", padx=4)

        # Кнопка добавления товара (только администратор)
        if self.can_edit:
            tk.Button(toolbar, text="Добавить товар",
                      command=self._add_product, font=styles.FONT_BOLD,
                      bg=styles.COLOR_ACCENT, fg=styles.COLOR_WHITE,
                      relief="flat", cursor="hand2",
                      activebackground=styles.COLOR_SECONDARY,
                      activeforeground=styles.COLOR_WHITE).pack(
                          side="right", padx=4)

    # --------------------- Прокручиваемая область --------------------
    def _build_list_area(self):
        """Холст с вертикальной прокруткой для карточек товаров."""
        area = tk.Frame(self, bg=styles.COLOR_BG)
        area.pack(fill="both", expand=True, padx=12, pady=(0, 12))

        self.canvas = tk.Canvas(area, bg=styles.COLOR_BG,
                                highlightthickness=0)
        scrollbar = tk.Scrollbar(area, orient="vertical",
                                 command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.list_frame = tk.Frame(self.canvas, bg=styles.COLOR_BG)
        self._window_id = self.canvas.create_window(
            (0, 0), window=self.list_frame, anchor="nw")

        self.list_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")))
        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.itemconfig(self._window_id, width=e.width))
        # Прокрутка колесом мыши
        self.canvas.bind_all("<Button-4>",
                             lambda e: self.canvas.yview_scroll(-1, "units"))
        self.canvas.bind_all("<Button-5>",
                             lambda e: self.canvas.yview_scroll(1, "units"))

    def _get_thumb(self, photo_name):
        """Загрузить миниатюру фото товара либо заглушку из ресурсов."""
        path = None
        if photo_name:
            candidate = os.path.join(IMAGES_DIR, photo_name)
            if os.path.exists(candidate):
                path = candidate
        if path is None:
            path = PLACEHOLDER  # картинка-заглушка picture.png

        if path in self._thumb_cache:
            return self._thumb_cache[path]
        try:
            image = Image.open(path)
            image.thumbnail(THUMB_SIZE, Image.LANCZOS)
            thumb = ImageTk.PhotoImage(image)
        except Exception:  # noqa: BLE001
            thumb = None
        self._thumb_cache[path] = thumb
        return thumb

    # --------------------- Загрузка и отрисовка ----------------------
    def reload_products(self):
        """Перечитать товары из БД с учётом поиска/фильтра/сортировки."""
        # Параметры действуют только для менеджера/администратора
        search = manufacturer_id = sort_field = None
        sort_desc = False
        if self.can_manage_tools:
            search = self.search_var.get().strip() or None
            label = self.filter_var.get()
            if label != "Все производители":
                manufacturer_id = self._manufacturer_map.get(label)
            sort_field, sort_desc = dict(SORT_OPTIONS)[self.sort_var.get()]

        try:
            products = self.db.get_products(
                search=search, manufacturer_id=manufacturer_id,
                sort_field=sort_field, sort_desc=sort_desc)
        except Exception as error:  # noqa: BLE001
            messagebox.showerror(
                "Ошибка", f"Не удалось загрузить товары.\n{error}")
            return

        # Очистка предыдущих карточек
        for widget in self.list_frame.winfo_children():
            widget.destroy()

        if not products:
            tk.Label(self.list_frame, text="Товары не найдены",
                     font=styles.FONT_SUBTITLE, bg=styles.COLOR_BG,
                     fg=styles.COLOR_TEXT).pack(pady=40)
            return

        for product in products:
            self._render_row(product)

    def _row_background(self, product):
        """Определить цвет фона строки товара по правилам задания."""
        if product["quantity"] == 0:
            return styles.COLOR_NO_STOCK              # нет на складе — голубой
        if product["discount"] > styles.DISCOUNT_THRESHOLD:
            return styles.COLOR_DISCOUNT              # скидка > 12% — #F4A460
        return styles.COLOR_WHITE

    def _render_row(self, product):
        """Отрисовать карточку одного товара."""
        bg = self._row_background(product)
        row = tk.Frame(self.list_frame, bg=bg, relief="solid", bd=1)
        row.pack(fill="x", pady=4, padx=2)

        # Фото товара (или заглушка)
        thumb = self._get_thumb(product["photo"])
        photo_label = tk.Label(row, image=thumb, bg=bg)
        photo_label.image = thumb
        photo_label.pack(side="left", padx=8, pady=8)

        # Блок текстовой информации
        info = tk.Frame(row, bg=bg)
        info.pack(side="left", fill="both", expand=True, padx=8, pady=6)

        tk.Label(info, text=product["name"], font=styles.FONT_BOLD,
                 bg=bg, anchor="w").pack(fill="x")
        meta = (f"Категория: {product['category_name']}   |   "
                f"Производитель: {product['manufacturer_name']}   |   "
                f"Поставщик: {product['supplier_name']}")
        tk.Label(info, text=meta, font=styles.FONT_SMALL, bg=bg,
                 anchor="w", fg="#333333").pack(fill="x")
        description = product["description"] or "Описание отсутствует"
        tk.Label(info, text=description, font=styles.FONT_SMALL, bg=bg,
                 anchor="w", wraplength=560, justify="left").pack(fill="x")
        extra = (f"Ед. изм.: {product['unit_name']}   |   "
                 f"На складе: {product['quantity']}   |   "
                 f"Скидка: {product['discount']}%   |   "
                 f"Артикул: {product['article']}")
        tk.Label(info, text=extra, font=styles.FONT_SMALL, bg=bg,
                 anchor="w", fg="#333333").pack(fill="x")

        # Блок цены справа
        self._render_price(row, product, bg)

        # Клик по карточке открывает форму редактирования (только админ)
        if self.can_edit:
            for widget in (row, info, photo_label):
                widget.bind("<Button-1>",
                            lambda e, p=product: self._edit_product(p))
                widget.config(cursor="hand2")

    def _render_price(self, row, product, bg):
        """Отобразить цену: при скидке — старая (зачёркнута) и итоговая."""
        price_box = tk.Frame(row, bg=bg)
        price_box.pack(side="right", padx=14)

        base_price = float(product["price"])
        final_price = float(product["final_price"])

        if product["discount"] > 0 and final_price < base_price:
            # Основная цена перечёркнута, красный шрифт
            tk.Label(price_box, text=f"{base_price:.2f} руб.",
                     font=styles.FONT_OLD_PRICE, bg=bg,
                     fg=styles.COLOR_OLD_PRICE).pack(anchor="e")
            # Итоговая цена — чёрный шрифт
            tk.Label(price_box, text=f"{final_price:.2f} руб.",
                     font=styles.FONT_PRICE, bg=bg,
                     fg=styles.COLOR_NEW_PRICE).pack(anchor="e")
        else:
            # Без скидки — только основная цена
            tk.Label(price_box, text=f"{base_price:.2f} руб.",
                     font=styles.FONT_PRICE, bg=bg,
                     fg=styles.COLOR_NEW_PRICE).pack(anchor="e")

    # --------------------------- Действия ----------------------------
    def _open_orders(self):
        """Открыть окно просмотра заказов."""
        OrdersWindow(self.app, self.db)

    def _add_product(self):
        """Открыть форму добавления нового товара."""
        self._open_form(product=None)

    def _edit_product(self, product):
        """Открыть форму редактирования выбранного товара."""
        self._open_form(product=product)

    def _open_form(self, product):
        """Открыть форму товара, запретив более одного окна одновременно."""
        if self._edit_window is not None and self._edit_window.winfo_exists():
            messagebox.showwarning(
                "Предупреждение",
                "Окно редактирования уже открыто.\n"
                "Закройте его, прежде чем открыть новое.")
            self._edit_window.focus_force()
            return
        self._edit_window = ProductForm(
            self.app, self.db, product=product,
            on_save=self.reload_products)
