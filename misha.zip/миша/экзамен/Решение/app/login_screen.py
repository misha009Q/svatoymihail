# -*- coding: utf-8 -*-
"""Экран авторизации (окно входа) — первый экран приложения."""
import os
import tkinter as tk
from tkinter import messagebox

from PIL import Image, ImageTk

import styles

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOGO_PATH = os.path.join(BASE_DIR, "resources", "icon.png")


class LoginScreen(tk.Frame):
    """Форма входа: логин/пароль из БД либо вход в роли гостя."""

    def __init__(self, app):
        super().__init__(app, bg=styles.COLOR_BG)
        self.app = app
        self._logo_image = None
        self._build()

    def _build(self):
        # Центрирующий контейнер
        container = tk.Frame(self, bg=styles.COLOR_BG)
        container.place(relx=0.5, rely=0.5, anchor="center")

        # Логотип компании из ресурсов (без искажения пропорций)
        try:
            image = Image.open(LOGO_PATH)
            image.thumbnail((140, 140), Image.LANCZOS)
            self._logo_image = ImageTk.PhotoImage(image)
            tk.Label(container, image=self._logo_image,
                     bg=styles.COLOR_BG).pack(pady=(0, 10))
        except Exception:  # noqa: BLE001
            pass

        tk.Label(container, text="ООО «СтройМатериалы»",
                 font=styles.FONT_TITLE, bg=styles.COLOR_BG,
                 fg=styles.COLOR_ACCENT).pack()
        tk.Label(container, text="Вход в систему",
                 font=styles.FONT_SUBTITLE, bg=styles.COLOR_BG,
                 fg=styles.COLOR_TEXT).pack(pady=(0, 18))

        # Поле логина
        tk.Label(container, text="Логин:", font=styles.FONT_NORMAL,
                 bg=styles.COLOR_BG, anchor="w").pack(fill="x")
        self.login_var = tk.StringVar()
        login_entry = tk.Entry(container, textvariable=self.login_var,
                               font=styles.FONT_NORMAL, width=34,
                               relief="solid", bd=1)
        login_entry.pack(pady=(2, 10), ipady=4)
        login_entry.focus_set()

        # Поле пароля
        tk.Label(container, text="Пароль:", font=styles.FONT_NORMAL,
                 bg=styles.COLOR_BG, anchor="w").pack(fill="x")
        self.password_var = tk.StringVar()
        self.password_entry = tk.Entry(
            container, textvariable=self.password_var, show="*",
            font=styles.FONT_NORMAL, width=34, relief="solid", bd=1)
        self.password_entry.pack(pady=(2, 6), ipady=4)

        # Чекбокс показа пароля (визуальная подсказка пользователю)
        self.show_password = tk.BooleanVar(value=False)
        tk.Checkbutton(container, text="Показать пароль",
                       variable=self.show_password,
                       command=self._toggle_password, bg=styles.COLOR_BG,
                       font=styles.FONT_SMALL,
                       activebackground=styles.COLOR_BG).pack(anchor="w")

        # Кнопка входа — акцентный цвет целевого действия
        tk.Button(container, text="Войти", command=self._on_login,
                  font=styles.FONT_BOLD, bg=styles.COLOR_ACCENT,
                  fg=styles.COLOR_WHITE, activebackground=styles.COLOR_SECONDARY,
                  activeforeground=styles.COLOR_WHITE, relief="flat",
                  cursor="hand2", width=30).pack(pady=(14, 8), ipady=6)

        # Кнопка входа в роли гостя — дополнительный фон
        tk.Button(container, text="Войти как гость",
                  command=self.app.login_as_guest, font=styles.FONT_NORMAL,
                  bg=styles.COLOR_SECONDARY, fg=styles.COLOR_WHITE,
                  activebackground=styles.COLOR_ACCENT,
                  activeforeground=styles.COLOR_WHITE, relief="flat",
                  cursor="hand2", width=30).pack(ipady=4)

        # Вход по нажатию Enter
        self.app.bind("<Return>", lambda event: self._on_login())

    def _toggle_password(self):
        """Переключить отображение символов пароля."""
        self.password_entry.config(
            show="" if self.show_password.get() else "*")

    def _on_login(self):
        """Обработать попытку входа: валидация полей и проверка в БД."""
        login = self.login_var.get().strip()
        password = self.password_var.get().strip()

        if not login or not password:
            messagebox.showwarning(
                "Предупреждение",
                "Заполните поля логина и пароля либо войдите как гость.")
            return

        try:
            user = self.app.db.authenticate(login, password)
        except Exception as error:  # noqa: BLE001
            messagebox.showerror(
                "Ошибка",
                f"Не удалось выполнить вход.\nПодробности: {error}")
            return

        if user is None:
            messagebox.showerror(
                "Ошибка авторизации",
                "Неверный логин или пароль.\n"
                "Проверьте правильность введённых данных и повторите попытку.")
            self.password_var.set("")
            return

        self.app.unbind("<Return>")
        self.app.login_as_user(user)
