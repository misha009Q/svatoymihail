# -*- coding: utf-8 -*-
"""Окно просмотра заказов для менеджера и администратора."""
import tkinter as tk
from tkinter import ttk, messagebox

import styles


class OrdersWindow(tk.Toplevel):
    """Модальное окно со списком заказов из базы данных."""

    def __init__(self, app, db):
        super().__init__(app)
        self.db = db
        self.title("ООО «СтройМатериалы» — Заказы")
        self.geometry("900x500")
        self.configure(bg=styles.COLOR_BG)
        self.transient(app)

        # Заголовок окна
        header = tk.Frame(self, bg=styles.COLOR_SECONDARY, height=48)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="Список заказов", font=styles.FONT_SUBTITLE,
                 bg=styles.COLOR_SECONDARY,
                 fg=styles.COLOR_WHITE).pack(side="left", padx=14, pady=8)

        self._build_table()
        self._load()

    def _build_table(self):
        """Таблица заказов на основе ttk.Treeview."""
        columns = ("id", "order_date", "delivery_date", "client",
                   "address", "code", "status", "positions", "qty")
        headers = ("№", "Дата заказа", "Дата доставки", "Клиент",
                   "Пункт выдачи", "Код", "Статус", "Позиций", "Кол-во")
        widths = (40, 100, 110, 170, 180, 60, 90, 70, 70)

        frame = tk.Frame(self, bg=styles.COLOR_BG)
        frame.pack(fill="both", expand=True, padx=10, pady=10)

        self.tree = ttk.Treeview(frame, columns=columns, show="headings")
        for col, head, width in zip(columns, headers, widths):
            self.tree.heading(col, text=head)
            self.tree.column(col, width=width, anchor="w")

        scrollbar = ttk.Scrollbar(frame, orient="vertical",
                                  command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.tree.pack(side="left", fill="both", expand=True)

    def _load(self):
        """Загрузить заказы из базы данных в таблицу."""
        try:
            orders = self.db.get_orders()
        except Exception as error:  # noqa: BLE001
            messagebox.showerror(
                "Ошибка", f"Не удалось загрузить заказы.\n{error}",
                parent=self)
            return
        for order in orders:
            self.tree.insert("", "end", values=(
                order["order_id"],
                order["order_date"].strftime("%d.%m.%Y")
                if order["order_date"] else "",
                order["delivery_date"].strftime("%d.%m.%Y")
                if order["delivery_date"] else "",
                order["client"],
                order["address"],
                order["receive_code"],
                order["status_name"],
                order["positions"],
                order["total_qty"],
            ))
