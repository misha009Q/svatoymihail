# -*- coding: utf-8 -*-
"""Форма добавления и редактирования товара (Модуль № 3).

Реализует:
  * загрузку данных товара при редактировании;
  * выпадающие списки категорий и производителей;
  * валидацию (цена/количество не отрицательны, обязательные поля);
  * работу с фото: выбор, ограничение 300x200, сохранение в папку,
    удаление старого фото при замене;
  * удаление товара (если он не присутствует в заказах).
"""
import os
import shutil
import uuid
import tkinter as tk
from tkinter import messagebox, filedialog

from PIL import Image, ImageTk

import styles

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
IMAGES_DIR = os.path.join(BASE_DIR, "images")
PLACEHOLDER = os.path.join(BASE_DIR, "resources", "picture.png")

# Ограничение размера сохраняемого фото товара
MAX_PHOTO_SIZE = (300, 200)
# Размер предпросмотра на форме
PREVIEW_SIZE = (200, 150)


class ProductForm(tk.Toplevel):
    """Окно-форма для добавления либо редактирования товара."""

    def __init__(self, app, db, product=None, on_save=None):
        super().__init__(app)
        self.db = db
        self.product = product            # None => добавление
        self.on_save = on_save            # колбэк обновления списка
        self.is_edit = product is not None

        self._new_photo_source = None     # путь к выбранному новому файлу
        self._photo_cleared = False       # признак удаления фото
        self._preview_image = None

        title = "Редактирование товара" if self.is_edit else "Добавление товара"
        self.title(f"ООО «СтройМатериалы» — {title}")
        self.geometry("640x720")
        self.configure(bg=styles.COLOR_BG)
        self.transient(app)
        self.grab_set()                   # модальность: одно окно за раз

        self._build()
        self._load_data()

    # --------------------------- Интерфейс ---------------------------
    def _build(self):
        """Построить элементы формы."""
        header = tk.Frame(self, bg=styles.COLOR_SECONDARY, height=46)
        header.pack(fill="x")
        header.pack_propagate(False)
        title = "Редактирование товара" if self.is_edit else "Новый товар"
        tk.Label(header, text=title, font=styles.FONT_SUBTITLE,
                 bg=styles.COLOR_SECONDARY,
                 fg=styles.COLOR_WHITE).pack(side="left", padx=14, pady=8)

        body = tk.Frame(self, bg=styles.COLOR_BG)
        body.pack(fill="both", expand=True, padx=16, pady=10)

        # Левая колонка — фото, правая — поля
        self.photo_label = tk.Label(body, bg=styles.COLOR_BG,
                                    relief="solid", bd=1)
        self.photo_label.grid(row=0, column=0, rowspan=2, padx=(0, 16),
                              pady=4, sticky="n")

        photo_buttons = tk.Frame(body, bg=styles.COLOR_BG)
        photo_buttons.grid(row=2, column=0, pady=6)
        tk.Button(photo_buttons, text="Выбрать фото",
                  command=self._choose_photo, font=styles.FONT_SMALL,
                  bg=styles.COLOR_SECONDARY, fg=styles.COLOR_WHITE,
                  relief="flat", cursor="hand2").pack(fill="x", pady=2)
        tk.Button(photo_buttons, text="Удалить фото",
                  command=self._clear_photo, font=styles.FONT_SMALL,
                  bg=styles.COLOR_BG, fg=styles.COLOR_TEXT,
                  relief="solid", bd=1, cursor="hand2").pack(fill="x", pady=2)

        # Поля формы
        fields = tk.Frame(body, bg=styles.COLOR_BG)
        fields.grid(row=0, column=1, rowspan=3, sticky="nw")
        self._build_fields(fields)

        # Нижняя панель кнопок
        self._build_buttons()

    def _build_fields(self, parent):
        """Создать поля ввода и выпадающие списки."""
        self.vars = {}
        row = 0

        def add_label(text):
            nonlocal row
            tk.Label(parent, text=text, font=styles.FONT_NORMAL,
                     bg=styles.COLOR_BG, anchor="w").grid(
                         row=row, column=0, sticky="w", pady=(6, 0))
            row += 1

        def add_entry(key, width=42):
            nonlocal row
            var = tk.StringVar()
            self.vars[key] = var
            tk.Entry(parent, textvariable=var, font=styles.FONT_NORMAL,
                     width=width, relief="solid", bd=1).grid(
                         row=row, column=0, sticky="w", ipady=3)
            row += 1

        # ID (только при редактировании, доступен только для чтения)
        if self.is_edit:
            add_label("ID товара:")
            self.vars["id"] = tk.StringVar()
            tk.Entry(parent, textvariable=self.vars["id"],
                     font=styles.FONT_NORMAL, width=42, relief="solid",
                     bd=1, state="readonly").grid(row=row, column=0,
                                                  sticky="w", ipady=3)
            row += 1

        add_label("Артикул:")
        add_entry("article")
        add_label("Наименование товара:")
        add_entry("name")

        # Категория (выпадающий список)
        add_label("Категория товара:")
        self.category_var = tk.StringVar()
        self._categories = self.db.get_categories()
        cat_names = [c["category_name"] for c in self._categories]
        tk.OptionMenu(parent, self.category_var,
                      *(cat_names or [""])).grid(
                          row=row, column=0, sticky="we")
        row += 1

        # Производитель (выпадающий список)
        add_label("Производитель:")
        self.manufacturer_var = tk.StringVar()
        self._manufacturers = self.db.get_manufacturers()
        man_names = [m["manufacturer_name"] for m in self._manufacturers]
        tk.OptionMenu(parent, self.manufacturer_var,
                      *(man_names or [""])).grid(
                          row=row, column=0, sticky="we")
        row += 1

        # Поставщик
        add_label("Поставщик:")
        add_entry("supplier")
        # Единица измерения
        add_label("Единица измерения:")
        add_entry("unit")
        # Цена
        add_label("Цена (руб.):")
        add_entry("price")
        # Скидка
        add_label("Действующая скидка (%):")
        add_entry("discount")
        # Количество
        add_label("Количество на складе:")
        add_entry("quantity")

        # Описание (многострочное)
        add_label("Описание товара:")
        self.description_text = tk.Text(parent, width=42, height=4,
                                        font=styles.FONT_NORMAL,
                                        relief="solid", bd=1, wrap="word")
        self.description_text.grid(row=row, column=0, sticky="w")

    def _build_buttons(self):
        """Нижняя панель: Сохранить, Удалить, Назад."""
        panel = tk.Frame(self, bg=styles.COLOR_BG)
        panel.pack(fill="x", side="bottom", padx=16, pady=12)

        # Кнопка «Назад» — возврат к списку (закрытие формы)
        tk.Button(panel, text="Назад", command=self._close,
                  font=styles.FONT_NORMAL, bg=styles.COLOR_BG,
                  fg=styles.COLOR_TEXT, relief="solid", bd=1,
                  cursor="hand2", width=12).pack(side="left")

        # Кнопка сохранения — акцентный цвет
        tk.Button(panel, text="Сохранить", command=self._save,
                  font=styles.FONT_BOLD, bg=styles.COLOR_ACCENT,
                  fg=styles.COLOR_WHITE, relief="flat", cursor="hand2",
                  activebackground=styles.COLOR_SECONDARY,
                  activeforeground=styles.COLOR_WHITE,
                  width=14).pack(side="right")

        # Кнопка удаления — только при редактировании
        if self.is_edit:
            tk.Button(panel, text="Удалить товар", command=self._delete,
                      font=styles.FONT_NORMAL, bg="#C0392B",
                      fg=styles.COLOR_WHITE, relief="flat", cursor="hand2",
                      width=14).pack(side="right", padx=8)

    def _show_preview(self, path):
        """Показать изображение в области предпросмотра."""
        try:
            image = Image.open(path)
            image.thumbnail(PREVIEW_SIZE, Image.LANCZOS)
            self._preview_image = ImageTk.PhotoImage(image)
            self.photo_label.config(image=self._preview_image, width=200,
                                    height=150)
        except Exception:  # noqa: BLE001
            self.photo_label.config(image="", text="нет фото", width=26,
                                    height=8)

    # --------------------------- Данные ------------------------------
    def _load_data(self):
        """Заполнить поля формы данными товара (при редактировании)."""
        if not self.is_edit:
            # Новый товар: ID не отображается, фото — заглушка
            self._current_photo = None
            self._show_preview(PLACEHOLDER)
            return

        product = self.product
        self.vars["id"].set(str(product["product_id"]))
        self.vars["article"].set(product["article"])
        self.vars["name"].set(product["name"])
        self.category_var.set(product["category_name"])
        self.manufacturer_var.set(product["manufacturer_name"])
        self.vars["supplier"].set(product["supplier_name"])
        self.vars["unit"].set(product["unit_name"])
        self.vars["price"].set(f"{float(product['price']):.2f}")
        self.vars["discount"].set(str(product["discount"]))
        self.vars["quantity"].set(str(product["quantity"]))
        self.description_text.insert("1.0", product["description"] or "")

        # Текущее фото товара
        self._current_photo = product["photo"]
        if product["photo"]:
            path = os.path.join(IMAGES_DIR, product["photo"])
            self._show_preview(path if os.path.exists(path) else PLACEHOLDER)
        else:
            self._show_preview(PLACEHOLDER)

    # ----------------------- Работа с фото ---------------------------
    def _choose_photo(self):
        """Выбрать новый файл изображения для товара."""
        path = filedialog.askopenfilename(
            parent=self, title="Выберите изображение товара",
            filetypes=[("Изображения", "*.jpg *.jpeg *.png *.bmp *.gif"),
                       ("Все файлы", "*.*")])
        if not path:
            return
        self._new_photo_source = path
        self._photo_cleared = False
        self._show_preview(path)

    def _clear_photo(self):
        """Сбросить фото товара на заглушку."""
        self._new_photo_source = None
        self._photo_cleared = True
        self._show_preview(PLACEHOLDER)

    # --------------------------- Валидация ---------------------------
    def _validate(self):
        """Проверить корректность введённых данных. Вернуть словарь или None."""
        article = self.vars["article"].get().strip()
        name = self.vars["name"].get().strip()
        supplier = self.vars["supplier"].get().strip()
        unit = self.vars["unit"].get().strip()
        category = self.category_var.get().strip()
        manufacturer = self.manufacturer_var.get().strip()

        # Обязательные текстовые поля
        if not all([article, name, supplier, unit, category, manufacturer]):
            messagebox.showwarning(
                "Предупреждение",
                "Заполните все обязательные поля: артикул, наименование, "
                "категорию, производителя, поставщика и единицу измерения.",
                parent=self)
            return None

        # Уникальность артикула
        exclude = self.product["product_id"] if self.is_edit else None
        if self.db.article_exists(article, exclude_id=exclude):
            messagebox.showerror(
                "Ошибка",
                f"Товар с артикулом «{article}» уже существует.\n"
                "Укажите другой артикул.", parent=self)
            return None

        # Цена: число, не отрицательное, допускает сотые
        try:
            price = float(self.vars["price"].get().replace(",", "."))
        except ValueError:
            messagebox.showerror(
                "Ошибка", "Цена должна быть числом (например, 199.99).",
                parent=self)
            return None
        if price < 0:
            messagebox.showerror(
                "Ошибка", "Цена не может быть отрицательной.", parent=self)
            return None

        # Скидка: целое 0..100
        try:
            discount = int(self.vars["discount"].get() or "0")
        except ValueError:
            messagebox.showerror(
                "Ошибка", "Скидка должна быть целым числом от 0 до 100.",
                parent=self)
            return None
        if not 0 <= discount <= 100:
            messagebox.showerror(
                "Ошибка", "Скидка должна быть в диапазоне от 0 до 100 %.",
                parent=self)
            return None

        # Количество: целое, не отрицательное
        try:
            quantity = int(self.vars["quantity"].get() or "0")
        except ValueError:
            messagebox.showerror(
                "Ошибка", "Количество должно быть целым числом.",
                parent=self)
            return None
        if quantity < 0:
            messagebox.showerror(
                "Ошибка", "Количество не может быть отрицательным.",
                parent=self)
            return None

        return {
            "article": article,
            "name": name,
            "description": self.description_text.get("1.0", "end").strip()
            or None,
            "category_id": self._lookup_id(
                self._categories, "category_name", category, "category_id"),
            "manufacturer_id": self._lookup_id(
                self._manufacturers, "manufacturer_name", manufacturer,
                "manufacturer_id"),
            "supplier": supplier,
            "unit": unit,
            "price": price,
            "discount": discount,
            "quantity": quantity,
        }

    @staticmethod
    def _lookup_id(rows, name_key, value, id_key):
        """Найти id справочника по названию."""
        for row in rows:
            if row[name_key] == value:
                return row[id_key]
        return None

    # --------------------------- Сохранение --------------------------
    def _persist_photo(self):
        """Сохранить новое фото (с ограничением 300x200) и вернуть имя файла.

        Возвращает: (имя_файла_или_None, нужно_ли_удалить_старое).
        """
        old_photo = self._current_photo

        # Фото явно удалено пользователем
        if self._photo_cleared and not self._new_photo_source:
            return None, bool(old_photo)

        # Новое фото не выбиралось — оставляем как было
        if not self._new_photo_source:
            return old_photo, False

        # Сохранение нового фото с приведением к 300x200
        os.makedirs(IMAGES_DIR, exist_ok=True)
        ext = os.path.splitext(self._new_photo_source)[1].lower()
        if ext not in (".jpg", ".jpeg", ".png", ".bmp", ".gif"):
            ext = ".png"
        filename = f"{uuid.uuid4().hex}{ext}"
        target = os.path.join(IMAGES_DIR, filename)

        image = Image.open(self._new_photo_source)
        image.thumbnail(MAX_PHOTO_SIZE, Image.LANCZOS)
        if image.mode in ("RGBA", "P") and ext in (".jpg", ".jpeg"):
            image = image.convert("RGB")
        image.save(target)
        return filename, bool(old_photo)

    def _remove_old_photo(self):
        """Удалить файл прежнего фото из папки приложения."""
        if not self._current_photo:
            return
        path = os.path.join(IMAGES_DIR, self._current_photo)
        if os.path.exists(path):
            try:
                os.remove(path)
            except OSError:
                pass

    def _save(self):
        """Проверить данные и сохранить товар (добавление/обновление)."""
        data = self._validate()
        if data is None:
            return

        try:
            # Разрешение справочников поставщика и единицы измерения
            data["supplier_id"] = self.db.get_or_create_supplier(
                data.pop("supplier"))
            data["unit_id"] = self.db.get_or_create_unit(data.pop("unit"))

            # Обработка фото
            photo_name, need_remove = self._persist_photo()
            data["photo"] = photo_name

            if self.is_edit:
                self.db.update_product(self.product["product_id"], data)
            else:
                self.db.add_product(data)

            # Удаление старого файла, если фото заменено или удалено
            if need_remove and photo_name != self._current_photo:
                self._remove_old_photo()
        except Exception as error:  # noqa: BLE001
            messagebox.showerror(
                "Ошибка", f"Не удалось сохранить товар.\n{error}",
                parent=self)
            return

        action = "обновлён" if self.is_edit else "добавлен"
        messagebox.showinfo("Готово", f"Товар успешно {action}.",
                            parent=self)
        if self.on_save:
            self.on_save()
        self._close()

    def _delete(self):
        """Удалить товар, если он не присутствует в заказах."""
        if self.db.product_in_orders(self.product["product_id"]):
            messagebox.showerror(
                "Удаление невозможно",
                "Этот товар присутствует в одном или нескольких заказах "
                "и не может быть удалён.", parent=self)
            return

        if not messagebox.askyesno(
                "Подтверждение удаления",
                f"Удалить товар «{self.product['name']}»?\n"
                "Это действие необратимо.", parent=self):
            return

        try:
            self.db.delete_product(self.product["product_id"])
            self._remove_old_photo()
        except Exception as error:  # noqa: BLE001
            messagebox.showerror(
                "Ошибка", f"Не удалось удалить товар.\n{error}",
                parent=self)
            return

        messagebox.showinfo("Готово", "Товар успешно удалён.", parent=self)
        if self.on_save:
            self.on_save()
        self._close()

    def _close(self):
        """Закрыть форму и снять модальность."""
        self.grab_release()
        self.destroy()
