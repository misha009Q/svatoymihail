# -*- coding: utf-8 -*-
"""Слой доступа к данным: подключение к PostgreSQL и запросы."""
import psycopg2
import psycopg2.extras

# Параметры подключения к базе данных ООО «СтройМатериалы»
DB_CONFIG = {
    "host": "127.0.0.1",
    "port": 5432,
    "dbname": "stroy_db",
    "user": "stroy_app",
    "password": "stroy123",
}


class Database:
    """Обёртка над соединением с PostgreSQL."""

    def __init__(self):
        self.conn = psycopg2.connect(**DB_CONFIG)
        self.conn.autocommit = False

    def close(self):
        if self.conn:
            self.conn.close()

    def _query(self, sql, params=None):
        """Выполнить SELECT и вернуть список словарей."""
        with self.conn.cursor(
                cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(sql, params or ())
            return cur.fetchall()

    def _execute(self, sql, params=None, returning=False):
        """Выполнить INSERT/UPDATE/DELETE с фиксацией транзакции."""
        with self.conn.cursor() as cur:
            cur.execute(sql, params or ())
            result = cur.fetchone() if returning else None
            self.conn.commit()
            return result

    # ----------------------- Авторизация -----------------------------
    def authenticate(self, login, password):
        """Проверить логин и пароль; вернуть данные пользователя или None."""
        rows = self._query(
            """
            SELECT u.user_id, u.full_name, u.login, r.role_name
            FROM users u
            JOIN roles r ON r.role_id = u.role_id
            WHERE u.login = %s AND u.password = %s
            """,
            (login, password),
        )
        return rows[0] if rows else None

    # ----------------------- Справочники ------------------------------
    def get_categories(self):
        return self._query(
            "SELECT category_id, category_name FROM categories "
            "ORDER BY category_name")

    def get_manufacturers(self):
        return self._query(
            "SELECT manufacturer_id, manufacturer_name FROM manufacturers "
            "ORDER BY manufacturer_name")

    def get_suppliers(self):
        return self._query(
            "SELECT supplier_id, supplier_name FROM suppliers "
            "ORDER BY supplier_name")

    def get_units(self):
        return self._query(
            "SELECT unit_id, unit_name FROM units ORDER BY unit_name")

    def get_or_create_supplier(self, name):
        """Вернуть id поставщика, создав запись при отсутствии."""
        rows = self._query(
            "SELECT supplier_id FROM suppliers WHERE supplier_name = %s",
            (name,))
        if rows:
            return rows[0]["supplier_id"]
        return self._execute(
            "INSERT INTO suppliers (supplier_name) VALUES (%s) "
            "RETURNING supplier_id", (name,), returning=True)[0]

    def get_or_create_unit(self, name):
        """Вернуть id единицы измерения, создав запись при отсутствии."""
        rows = self._query(
            "SELECT unit_id FROM units WHERE unit_name = %s", (name,))
        if rows:
            return rows[0]["unit_id"]
        return self._execute(
            "INSERT INTO units (unit_name) VALUES (%s) "
            "RETURNING unit_id", (name,), returning=True)[0]

    # ----------------------- Товары -----------------------------------
    # Полное представление товара со всеми связанными названиями.
    PRODUCT_SELECT = """
        SELECT p.product_id, p.article, p.name, p.description,
               p.price, p.discount, p.quantity, p.photo,
               u.unit_id, u.unit_name,
               c.category_id, c.category_name,
               m.manufacturer_id, m.manufacturer_name,
               s.supplier_id, s.supplier_name,
               ROUND(p.price * (1 - p.discount / 100.0), 2) AS final_price
        FROM products p
        JOIN units u         ON u.unit_id = p.unit_id
        JOIN categories c    ON c.category_id = p.category_id
        JOIN manufacturers m ON m.manufacturer_id = p.manufacturer_id
        JOIN suppliers s     ON s.supplier_id = p.supplier_id
    """

    def get_products(self, search=None, manufacturer_id=None,
                     sort_field=None, sort_desc=False):
        """Список товаров с поиском, фильтром по производителю и сортировкой.

        Поиск ведётся по всем текстовым атрибутам одновременно.
        Допустимые поля сортировки ограничены белым списком.
        """
        sql = self.PRODUCT_SELECT
        conditions = []
        params = []

        if search:
            like = "%" + search.strip() + "%"
            conditions.append(
                "(p.article ILIKE %s OR p.name ILIKE %s "
                "OR p.description ILIKE %s OR c.category_name ILIKE %s "
                "OR m.manufacturer_name ILIKE %s "
                "OR s.supplier_name ILIKE %s OR u.unit_name ILIKE %s)")
            params.extend([like] * 7)

        if manufacturer_id:
            conditions.append("p.manufacturer_id = %s")
            params.append(manufacturer_id)

        if conditions:
            sql += " WHERE " + " AND ".join(conditions)

        allowed_sort = {
            "quantity": "p.quantity",
            "price": "p.price",
            "discount": "p.discount",
        }
        if sort_field in allowed_sort:
            direction = "DESC" if sort_desc else "ASC"
            sql += f" ORDER BY {allowed_sort[sort_field]} {direction}, " \
                   f"p.product_id"
        else:
            sql += " ORDER BY p.product_id"

        return self._query(sql, params)

    def get_product(self, product_id):
        """Получить один товар по идентификатору."""
        rows = self._query(
            self.PRODUCT_SELECT + " WHERE p.product_id = %s", (product_id,))
        return rows[0] if rows else None

    def get_next_product_id(self):
        """Следующий ID товара: +1 к максимальному в БД."""
        rows = self._query(
            "SELECT COALESCE(MAX(product_id), 0) + 1 AS next_id FROM products")
        return rows[0]["next_id"]

    def article_exists(self, article, exclude_id=None):
        """Проверить занятость артикула (с исключением текущего товара)."""
        sql = "SELECT 1 FROM products WHERE article = %s"
        params = [article]
        if exclude_id is not None:
            sql += " AND product_id <> %s"
            params.append(exclude_id)
        return bool(self._query(sql, params))

    def add_product(self, data):
        """Добавить товар. data — словарь с полями товара."""
        return self._execute(
            """
            INSERT INTO products (article, name, description, unit_id,
                category_id, manufacturer_id, supplier_id, price,
                discount, quantity, photo)
            VALUES (%(article)s, %(name)s, %(description)s, %(unit_id)s,
                %(category_id)s, %(manufacturer_id)s, %(supplier_id)s,
                %(price)s, %(discount)s, %(quantity)s, %(photo)s)
            RETURNING product_id
            """,
            data, returning=True)[0]

    def update_product(self, product_id, data):
        """Обновить существующий товар."""
        data = dict(data, product_id=product_id)
        self._execute(
            """
            UPDATE products SET article = %(article)s, name = %(name)s,
                description = %(description)s, unit_id = %(unit_id)s,
                category_id = %(category_id)s,
                manufacturer_id = %(manufacturer_id)s,
                supplier_id = %(supplier_id)s, price = %(price)s,
                discount = %(discount)s, quantity = %(quantity)s,
                photo = %(photo)s
            WHERE product_id = %(product_id)s
            """,
            data)

    def product_in_orders(self, product_id):
        """Проверить, присутствует ли товар хотя бы в одном заказе."""
        return bool(self._query(
            "SELECT 1 FROM order_items WHERE product_id = %s LIMIT 1",
            (product_id,)))

    def delete_product(self, product_id):
        """Удалить товар по идентификатору."""
        self._execute("DELETE FROM products WHERE product_id = %s",
                      (product_id,))

    # ----------------------- Заказы -----------------------------------
    def get_orders(self):
        """Список заказов с данными клиента, пункта выдачи и статуса."""
        return self._query(
            """
            SELECT o.order_id, o.order_date, o.delivery_date,
                   o.receive_code, pp.address, u.full_name AS client,
                   st.status_name,
                   COUNT(oi.order_item_id) AS positions,
                   COALESCE(SUM(oi.quantity), 0) AS total_qty
            FROM orders o
            JOIN pickup_points pp  ON pp.pickup_id = o.pickup_id
            JOIN users u           ON u.user_id = o.client_id
            JOIN order_statuses st ON st.status_id = o.status_id
            LEFT JOIN order_items oi ON oi.order_id = o.order_id
            GROUP BY o.order_id, pp.address, u.full_name, st.status_name
            ORDER BY o.order_id
            """)
