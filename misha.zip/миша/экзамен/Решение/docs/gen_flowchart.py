#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Блок-схема алгоритма авторизации по ГОСТ 19.701-90 (формат PDF)."""
import os
from graphviz import Digraph

OUT_DIR = "/home/user01/Рабочий стол/миша/экзамен/Решение/docs"
OUT = os.path.join(OUT_DIR, "Блок-схема")

g = Digraph("flow", format="pdf")
g.attr(rankdir="TB", bgcolor="white", nodesep="0.45", ranksep="0.5",
       fontname="Carlito")
g.attr("node", fontname="Carlito", fontsize="11", style="filled",
       fillcolor="white", color="black")
g.attr("edge", fontname="Carlito", fontsize="10", color="black")


def terminator(name, text):
    """Терминатор (начало/конец) — по ГОСТ скруглённый прямоугольник."""
    g.node(name, text, shape="box", style="rounded,filled",
           fillcolor="#DAA520")


def process(name, text):
    """Процесс — прямоугольник."""
    g.node(name, text, shape="box")


def io(name, text):
    """Ввод/вывод данных — параллелограмм."""
    g.node(name, text, shape="parallelogram")


def decision(name, text):
    """Решение — ромб."""
    g.node(name, text, shape="diamond", fillcolor="#F5F5F5")


# --------------------------- Узлы схемы ------------------------------
terminator("start", "Начало")
process("show_login", "Отображение окна входа")
io("input", "Ввод логина и пароля")
decision("guest", "Выбран режим\nгостя?")
process("guest_mode", "Роль = «Гость»")
decision("empty", "Поля логина\nи пароля\nзаполнены?")
process("msg_empty", "Сообщение об ошибке:\n«Заполните все поля»")
process("db_query", "Запрос пользователя\nв базе данных")
decision("found", "Пользователь\nнайден?")
process("msg_bad", "Сообщение об ошибке:\n«Неверный логин\nили пароль»")
process("set_role", "Определение роли\nпользователя из БД")
process("open_main", "Открытие списка товаров\nсогласно роли")
terminator("end", "Конец")

# --------------------------- Связи -----------------------------------
g.edge("start", "show_login")
g.edge("show_login", "input")
g.edge("input", "guest")
g.edge("guest", "guest_mode", label="Да")
g.edge("guest_mode", "open_main")
g.edge("guest", "empty", label="Нет")
g.edge("empty", "msg_empty", label="Нет")
g.edge("msg_empty", "show_login")
g.edge("empty", "db_query", label="Да")
g.edge("db_query", "found")
g.edge("found", "msg_bad", label="Нет")
g.edge("msg_bad", "show_login")
g.edge("found", "set_role", label="Да")
g.edge("set_role", "open_main")
g.edge("open_main", "end")

g.render(OUT, cleanup=True)
print("Блок-схема создана:", OUT + ".pdf")
