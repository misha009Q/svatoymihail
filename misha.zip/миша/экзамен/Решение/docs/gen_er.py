#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Генерация ER-диаграммы БД в формате PDF средствами Graphviz."""
import os
from graphviz import Digraph

OUT_DIR = "/home/user01/Рабочий стол/миша/экзамен/Решение/docs"
OUT = os.path.join(OUT_DIR, "ER-диаграмма")

# Цвет акцента из руководства по стилю
HEAD = "#DAA520"

g = Digraph("ER", format="pdf")
g.attr(rankdir="LR", splines="ortho", nodesep="0.6", ranksep="1.0",
       bgcolor="white", fontname="Carlito")
g.attr("node", shape="plaintext", fontname="Carlito")
g.attr("edge", color="#555555", arrowhead="none", fontname="Carlito")


def table(name, title, rows):
    """rows: список кортежей (key, attr_text). key in {PK, FK, PFK, ''}."""
    html = [
        '<<TABLE BORDER="0" CELLBORDER="1" CELLSPACING="0" CELLPADDING="4">',
        f'<TR><TD BGCOLOR="{HEAD}" COLSPAN="2">'
        f'<B>{title}</B></TD></TR>',
    ]
    for key, attr in rows:
        badge = ""
        if key == "PK":
            badge = "<B>PK</B>"
        elif key == "FK":
            badge = "<I>FK</I>"
        elif key == "PFK":
            badge = "<B>PK</B>,<I>FK</I>"
        html.append(
            f'<TR><TD ALIGN="LEFT" WIDTH="38">{badge}</TD>'
            f'<TD ALIGN="LEFT">{attr}</TD></TR>')
    html.append("</TABLE>>")
    g.node(name, "\n".join(html))


# ----------------------------- Таблицы -------------------------------
table("roles", "roles", [
    ("PK", "role_id"), ("", "role_name")])
table("units", "units", [
    ("PK", "unit_id"), ("", "unit_name")])
table("categories", "categories", [
    ("PK", "category_id"), ("", "category_name")])
table("manufacturers", "manufacturers", [
    ("PK", "manufacturer_id"), ("", "manufacturer_name")])
table("suppliers", "suppliers", [
    ("PK", "supplier_id"), ("", "supplier_name")])
table("order_statuses", "order_statuses", [
    ("PK", "status_id"), ("", "status_name")])
table("pickup_points", "pickup_points", [
    ("PK", "pickup_id"), ("", "address")])
table("users", "users", [
    ("PK", "user_id"), ("", "full_name"), ("", "login"),
    ("", "password"), ("FK", "role_id")])
table("products", "products", [
    ("PK", "product_id"), ("", "article"), ("", "name"),
    ("", "description"), ("FK", "unit_id"), ("FK", "category_id"),
    ("FK", "manufacturer_id"), ("FK", "supplier_id"), ("", "price"),
    ("", "discount"), ("", "quantity"), ("", "photo")])
table("orders", "orders", [
    ("PK", "order_id"), ("", "order_date"), ("", "delivery_date"),
    ("FK", "pickup_id"), ("FK", "client_id"), ("", "receive_code"),
    ("FK", "status_id")])
table("order_items", "order_items", [
    ("PK", "order_item_id"), ("FK", "order_id"),
    ("FK", "product_id"), ("", "quantity")])

# ----------------------------- Связи ---------------------------------
# crow's foot: arrowtail=crow (много), arrowhead=tee (один)
g.attr("edge", dir="both", arrowtail="crow", arrowhead="tee")
g.edge("roles", "users")
g.edge("units", "products")
g.edge("categories", "products")
g.edge("manufacturers", "products")
g.edge("suppliers", "products")
g.edge("pickup_points", "orders")
g.edge("users", "orders")
g.edge("order_statuses", "orders")
g.edge("orders", "order_items")
g.edge("products", "order_items")

g.render(OUT, cleanup=True)
print("ER-диаграмма создана:", OUT + ".pdf")
